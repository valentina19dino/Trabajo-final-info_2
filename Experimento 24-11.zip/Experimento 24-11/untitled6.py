import sys
import random
from PyQt5.QtWidgets import QApplication, QMainWindow, QMessageBox, QWidget, QPushButton
from PyQt5.uic import loadUi
import mysql.connector
import pygame

# Clase de la ventana principal (ventana_1)
class VentanaPrincipal(QMainWindow):
    def __init__(self):
        super(VentanaPrincipal, self).__init__()
        loadUi("ventana_1.ui", self)  # Carga la interfaz principal
        self.boton_ingresar.clicked.connect(self.guardar_datos)  # Botón para guardar datos
        self.boton_juego.clicked.connect(self.abrir_juego)  # Botón para abrir el juego

    def guardar_datos(self):
        # Obtén los datos ingresados en los campos
        nombre = self.lineEdit.text()
        edad = self.lineEdit_2.text()
        genero = self.lineEdit_3.text()
        identificacion = self.lineEdit_4.text()

        # Valida que los campos no estén vacíos
        if not (nombre and edad and genero and identificacion):
            QMessageBox.warning(self, "Advertencia", "Por favor, complete todos los campos.")
            return

        # Conexión a la base de datos
        try:
            SERVER = 'localhost'
            USER = 'informatica2'
            PASSWD = 'bio123'
            DB = 'info_2'

            cnx = mysql.connector.connect(user=USER, password=PASSWD, host=SERVER, database=DB)

            cursor = cnx.cursor()
            sql_insert = """INSERT INTO usuarios (nombre, edad, genero, identificacion) VALUES (%s,%s,%s,%s)"""
            cursor.execute(sql_insert, (nombre, edad, genero, identificacion))
            cnx.commit()

            QMessageBox.information(self, "Éxito", "Datos guardados correctamente.")

        except mysql.connector.Error as error:
            QMessageBox.critical(self, "Error", f"No se pudo guardar la información: {error}")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Ocurrió un error inesperado: {str(e)}")

        finally:
            if 'cnx' in locals() and cnx.is_connected():
                cursor.close()
                cnx.close()

    def abrir_juego(self):
        self.ventana_juego = VentanaJuego(self)  # Crea una instancia del juego
        self.ventana_juego.show()  # Muestra el widget del juego


# Clase del juego (ventana_3 como QWidget)
class VentanaJuego(QWidget):
    def __init__(self, parent=None):
        super(VentanaJuego, self).__init__()
        loadUi("ventana_3.ui", self)  # Carga la interfaz del juego
        self.parent = parent  # Referencia a la ventana principal
        self.boton_continuar.clicked.connect(self.volver_a_principal)  # Botón "Continuar"
        self.init_juego()

    def init_juego(self):
        # Configuración inicial del juego
        pygame.init()
        self.screen = pygame.display.set_mode([900, 600])
        self.clock = pygame.time.Clock()
        self.meteoros = pygame.sprite.Group()
        self.jugador = Player()
        self.meteoros.add(self.crear_meteoros(10))

        # Inicia el juego en un hilo separado
        self.run_game()

    def crear_meteoros(self, cantidad):
        meteoros = []
        for _ in range(cantidad):
            meteor = Meteor()
            meteor.rect.x = random.randrange(900)
            meteor.rect.y = random.randrange(600)
            meteoros.append(meteor)
        return meteoros

    def run_game(self):
        # Lógica principal del juego
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
            self.clock.tick(60)
            self.actualizar_juego()

    def actualizar_juego(self):
        # Actualiza las posiciones y la lógica del juego
        pass

    def volver_a_principal(self):
        """Cierra el juego y regresa a la ventana principal."""
        self.close()


# Clase Meteor para los meteoritos
class Meteor(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((50, 50))
        self.image.fill((255, 0, 0))  # Color rojo para el meteorito
        self.rect = self.image.get_rect()


# Clase Player para el jugador
class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((50, 50))
        self.image.fill((0, 255, 0))  # Color verde para el jugador
        self.rect = self.image.get_rect()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    ventana_principal = VentanaPrincipal()
    ventana_principal.show()
    sys.exit(app.exec_())

