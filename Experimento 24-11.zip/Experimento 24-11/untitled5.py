import pygame, random
import pandas as pd
from datetime import datetime
import matplotlib.pyplot as plt
import seaborn as sns


# Colores
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

# Clase Meteor
class Meteor(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__() # Constructor clase base
        self.image = pygame.image.load("meteor.png").convert() # cargar imagen
        self.image.set_colorkey(BLACK) # no color negro
        self.rect = self.image.get_rect() # posición y tamaño

# Clase Jugador
class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load("player.png").convert()
        self.image.set_colorkey(BLACK)
        self.rect = self.image.get_rect()

# Modelo de datos del juego
class GameModel:
    def __init__(self):
        self.score = 0
        self.start_time = datetime.now() # Registra el tiempo, no lo muestra
        self.last_capture_time = self.start_time   # ultimo tiempo
        self.data = []   # Lista para almacenar los datos de cada intento

    def actualizar_datos(self):
        current_time = datetime.now() #tiempo actual
        reaction_time = (current_time - self.last_capture_time).total_seconds() #captura tiempo de reacción 
        self.last_capture_time = current_time # ultimo tiempo de captura 
        self.score += 1   # incrementa la puntación 


        # Almacena datos
        self.data.append({
            "Intento": self.score,
            "Tiempo_de_reaccion": reaction_time,
            "Tiempo_transcurrido": (current_time - self.start_time).total_seconds()
        })

    def obtener_datos(self):
        return pd.DataFrame(self.data)

# Vista para mostrar los elementos
class GameView:
    def __init__(self, screen, all_sprite_list):
        self.screen = screen # pantalla del juego 
        self.all_sprite_list = all_sprite_list # lista jugador, meteoros

    def actualizar_pantalla(self):
        self.screen.fill((255, 255, 255))  # Fondo blanco
        self.all_sprite_list.draw(self.screen)  # Dibujo los sprite(meteoros) en la pantalla
        pygame.display.flip()  # Actualizar pantalla

# Controlador del juego
class GameController:
    def __init__(self, model, view, player, meteor_list):
        self.model = model
        self.view = view
        self.player = player
        self.meteor_list = meteor_list
        self.done = False

    def manejar_eventos(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.done = True

    def actualizar_logica(self):
        mouse_pos = pygame.mouse.get_pos()
        self.player.rect.x, self.player.rect.y = mouse_pos

        meteor_hit_list = pygame.sprite.spritecollide(self.player, self.meteor_list, True)
        for meteor in meteor_hit_list:
            self.model.actualizar_datos() # actualiza datos cada vez que el jugador colisiona con el meteoro

    def ejecutar_juego(self):
        while not self.done:
            self.manejar_eventos()
            self.actualizar_logica()
            self.view.actualizar_pantalla()

        self.mostrar_grafica()
        

    def mostrar_grafica(self):
        df = self.model.obtener_datos() # datos en dataframe

        sns.set(style="whitegrid")
        plt.figure(figsize=(10, 6))

        plt.plot(df["Intento"], df["Tiempo_de_reaccion"], marker='o', color='b', label="Tiempo de Reacción")
        plt.title("Evolución del Tiempo de Reacción durante el Juego")
        plt.xlabel("Intentos")
        plt.ylabel("Tiempo de Reacción (segundos)")

        plt.legend()
        plt.show()


# Inicialización de Pygame y configuración
pygame.init() # inicia juego 
screen = pygame.display.set_mode([900, 600]) # tamaño pantalla
clock = pygame.time.Clock() # controla el tiempo con un reloj

# Crea juego
model = GameModel() 

meteor_list = pygame.sprite.Group()
all_sprite_list = pygame.sprite.Group()

for i in range(50): # Genera 50 meteoritos
    meteor = Meteor()
    meteor.rect.x = random.randrange(900)
    meteor.rect.y = random.randrange(600)
    meteor_list.add(meteor) # agrega el meteorito al grupo de meteoritos
    all_sprite_list.add(meteor) # agrega el meteorito al grupo de sprite

player = Player()
all_sprite_list.add(player)

view = GameView(screen, all_sprite_list)
controller = GameController(model, view, player, meteor_list)

# Ejecutar juego
controller.ejecutar_juego()

# Finalizar Pygame
pygame.quit()
