from modelo import Modelo
from vista import Ventana, Ventana2
import sys
from PyQt5.QtWidgets import QApplication

class Controlador:
    def __init__(self):
        self.modelo = Modelo()
        self.app = QApplication(sys.argv)
        self.ventana1 = Ventana(self)
        self.ventana2 = None

    def guardar_datos(self):
        nombre = self.ventana1.lineEdit.text()
        edad = self.ventana1.lineEdit_2.text()
        genero = self.ventana1.lineEdit_3.text()
        identificacion = self.ventana1.lineEdit_4.text()

        if not (nombre and edad and genero and identificacion):
            self.ventana1.mostrar_advertencia("Por favor, complete todos los campos.")
            return

        if self.modelo.guardar_datos(nombre, edad, genero, identificacion):
            self.ventana1.mostrar_mensaje("Éxito", "Datos guardados correctamente.")
            self.abrir_ventana2()
        else:
            self.ventana1.mostrar_advertencia("No se pudo guardar la información.")

    def abrir_ventana2(self):
        self.ventana2 = Ventana2(self)
        self.ventana2.show()
        self.ventana1.close()

    def jugar_teclado(self):
        self.modelo.juego_escritura()

    def jugar_mouse(self):
        self.modelo.juego_mouse()

    def salir(self):
        self.ventana1 = Ventana(self)
        self.ventana1.show()
        self.ventana2.close()

    def ejecutar(self):
        self.ventana1.show()
        sys.exit(self.app.exec_())

if __name__ == "__main__":
    controlador = Controlador()
    controlador.ejecutar()
