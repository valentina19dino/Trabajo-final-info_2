import mysql.connector
import pygame
import random
from datetime import datetime
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd

class Modelo:
    def __init__(self):
        self.SERVER = 'localhost'
        self.USER = 'informatica2'
        self.PASSWD = 'bio123'
        self.DB = 'info_2'

    def guardar_datos(self, nombre, edad, genero, identificacion):
        try:
            cnx = mysql.connector.connect(user=self.USER, password=self.PASSWD, host=self.SERVER, database=self.DB)
            cursor = cnx.cursor()
            sql_insert = """INSERT INTO usuarios (nombre, edad, genero, identificacion) VALUES (%s, %s, %s, %s)"""
            cursor.execute(sql_insert, (nombre, edad, genero, identificacion))
            cnx.commit()
            return True
        except mysql.connector.Error as error:
            print(f"Error: {error}")
            return False
        finally:
            if cnx.is_connected():
                cursor.close()
                cnx.close()

    # Juego de escritura
class JuegoMecanografia:
    def juego_escritura(self):
        pygame.init()
        WIDTH, HEIGHT = 800, 600
        screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption("Juego de Escritura")
        FONT = pygame.font.Font(None, 74)
        SMALL_FONT = pygame.font.Font(None, 50)
        WHITE = (255, 255, 255)
        BLACK = (0, 0, 0)
        RED = (255, 0, 0)
        GREEN = (0, 255, 0)

        PALABRAS = ["cielo", "vivir", "adaptación", "Ayudar", "coordinación", "escritura", "rehabilitación"]
        score = 0
        start_time = pygame.time.get_ticks() / 1000
        tiempos_reaccion = []
        palabra_actual = random.choice(PALABRAS)
        entrada_usuario = ""
        feedback = ""
        feedback_color = BLACK
        terminado = False

        while not terminado:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    terminado = True
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_BACKSPACE:
                        entrada_usuario = entrada_usuario[:-1]
                    elif event.key == pygame.K_RETURN:
                        if entrada_usuario.strip().lower() == palabra_actual.lower():
                            tiempo_reaccion = pygame.time.get_ticks() / 1000 - start_time
                            tiempos_reaccion.append(tiempo_reaccion)
                            score += 1
                            feedback = f"¡Correcto! Tiempo: {tiempo_reaccion:.2f}s"
                            feedback_color = GREEN
                            entrada_usuario = ""
                            palabra_actual = random.choice(PALABRAS)
                            start_time = pygame.time.get_ticks() / 1000
                        else:
                            feedback = "Incorrecto. Intenta de nuevo."
                            feedback_color = RED
                            entrada_usuario = ""
                    else:
                        entrada_usuario += event.unicode

            screen.fill(WHITE)
            texto_palabra = FONT.render(palabra_actual, True, BLACK)
            screen.blit(texto_palabra, (WIDTH // 2 - texto_palabra.get_width() // 2, HEIGHT // 3))
            texto_entrada = FONT.render(entrada_usuario, True, BLACK)
            screen.blit(texto_entrada, (WIDTH // 2 - texto_entrada.get_width() // 2, HEIGHT // 2))
            texto_feedback = SMALL_FONT.render(feedback, True, feedback_color)
            screen.blit(texto_feedback, (WIDTH // 2 - texto_feedback.get_width() // 2, HEIGHT // 1.5))
            texto_score = SMALL_FONT.render(f"Puntuación: {score}", True, BLACK)
            screen.blit(texto_score, (20, 20))
            pygame.display.flip()

        self.mostrar_graficas(tiempos_reaccion)

    def mostrar_graficas(self, tiempos_reaccion):
        if not tiempos_reaccion:
            print("No se capturaron tiempos de reacción.")
            return
        
        # Uso de numpy para estadísticas
        tiempos_np = np.array(tiempos_reaccion)
        promedio = np.mean(tiempos_np)
        desviacion = np.std(tiempos_np)
        
        print(f"Promedio de tiempos: {promedio:.2f}s")
        print(f"Desviación estándar: {desviacion:.2f}s")
        
        # Crear un DataFrame con pandas
        datos = pd.DataFrame({
            "Intento": range(1, len(tiempos_reaccion) + 1),
            "Tiempo de Reacción": tiempos_reaccion
        })
        print("Datos capturados:\n", datos)
        
        # Configurar y mostrar la gráfica
        sns.set(style="whitegrid")
        plt.figure(figsize=(10, 6))
        plt.plot(datos["Intento"], datos["Tiempo de Reacción"], marker="o", color="b", label="Tiempo de Reacción")
        plt.title("Evolución del Tiempo de Reacción")
        plt.xlabel("Intentos")
        plt.ylabel("Tiempo de Reacción (segundos)")
        plt.legend()
        plt.show()



class JuegoMouse:
    def juego_mouse(self):
        BLACK = (0, 0, 0)

        # Clase Meteor
        class Meteor(pygame.sprite.Sprite):
            def __init__(self):
                super().__init__()
                self.image = pygame.image.load("meteor.png").convert()
                self.image.set_colorkey(BLACK)
                self.rect = self.image.get_rect()

        # Clase Jugador
        class Player(pygame.sprite.Sprite):
            def __init__(self):
                super().__init__()
                self.image = pygame.image.load("player.png").convert()
                self.image.set_colorkey(BLACK)
                self.rect = self.image.get_rect()

        # Modelo de datos del juego
        class GameModel:
            def __init__(self):
                self.score = 0
                self.start_time = datetime.now()
                self.last_capture_time = self.start_time
                self.data = []

            def actualizar_datos(self):
                current_time = datetime.now()
                reaction_time = (current_time - self.last_capture_time).total_seconds()
                self.last_capture_time = current_time
                self.score += 1

                self.data.append({
                    "Intento": self.score,
                    "Tiempo_de_reaccion": reaction_time,
                    "Tiempo_transcurrido": (current_time - self.start_time).total_seconds()
                })

            def obtener_datos(self):
                return pd.DataFrame(self.data)

        # Vista para mostrar los elementos
        class GameView:
            def __init__(self, screen, all_sprite_list):
                self.screen = screen
                self.all_sprite_list = all_sprite_list

            def actualizar_pantalla(self):
                self.screen.fill((255, 255, 255))  # Fondo blanco
                self.all_sprite_list.draw(self.screen)
                pygame.display.flip()  # Actualizar pantalla

        # Controlador del juego
        class GameController:
            def __init__(self, model, view, player, meteor_list):
                self.model = model
                self.view = view
                self.player = player
                self.meteor_list = meteor_list
                self.done = False

            def manejar_eventos(self):
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        self.done = True

            def actualizar_logica(self):
                mouse_pos = pygame.mouse.get_pos()
                self.player.rect.x, self.player.rect.y = mouse_pos

                meteor_hit_list = pygame.sprite.spritecollide(self.player, self.meteor_list, True)
                for meteor in meteor_hit_list:
                    self.model.actualizar_datos()

            def ejecutar_juego(self):
                while not self.done:
                    self.manejar_eventos()
                    self.actualizar_logica()
                    self.view.actualizar_pantalla()

                self.mostrar_grafica()

            def mostrar_grafica(self):
                df = self.model.obtener_datos()

                if df.empty:
                    print("No se registraron tiempos de reacción.")
                    return

                # Calcular estadísticas con numpy
                tiempos_reaccion = df["Tiempo_de_reaccion"].to_numpy()
                promedio = np.mean(tiempos_reaccion)
                desviacion = np.std(tiempos_reaccion)

                print(f"Promedio de tiempos: {promedio:.2f}s")
                print(f"Desviación estándar: {desviacion:.2f}s")
                print("Datos registrados:\n", df)

                # Graficar con Seaborn y Matplotlib
                sns.set(style="whitegrid")
                plt.figure(figsize=(10, 6))
                plt.plot(df["Intento"], df["Tiempo_de_reaccion"], marker='o', color='b', label="Tiempo de Reacción")
                plt.title("Evolución del Tiempo de Reacción durante el Juego")
                plt.xlabel("Intentos")
                plt.ylabel("Tiempo de Reacción (segundos)")
                plt.legend()
                plt.show()

        # Inicialización de Pygame y configuración
        pygame.init()
        screen = pygame.display.set_mode([900, 600])
        clock = pygame.time.Clock()

        # Crear instancias
        model = GameModel()

        meteor_list = pygame.sprite.Group()
        all_sprite_list = pygame.sprite.Group()

        for i in range(50):
            meteor = Meteor()
            meteor.rect.x = random.randrange(900)
            meteor.rect.y = random.randrange(600)
            meteor_list.add(meteor)
            all_sprite_list.add(meteor)

        player = Player()
        all_sprite_list.add(player)

        view = GameView(screen, all_sprite_list)
        controller = GameController(model, view, player, meteor_list)
        controller.ejecutar_juego()


        
        
        
