import sys
import mysql.connector
from PyQt5.QtWidgets import QApplication, QMainWindow, QMessageBox
from PyQt5.uic import loadUi

class Ventana(QMainWindow):
    def __init__(self):
        super(Ventana, self).__init__()
        loadUi("ventana_1.ui", self)  # Carga la interfaz creada con Qt Designer
        
        # Conecta el botón de guardar con la función que maneja la base de datos
        self.boton_ingresar.clicked.connect(self.guardar_datos)
    
    def guardar_datos(self):
        # Obtén los datos ingresados en los campos
        nombre = self.lineEdit.text()
        edad = self.lineEdit_2.text()
        genero = self.lineEdit_3.text()
        identificacion = self.lineEdit_4.text()
        
        # Valida que los campos no estén vacíos
        if not (nombre and edad and genero and identificacion):
            QMessageBox.warning(self, "Advertencia", "Por favor, complete todos los campos.")
            return

        # Intenta conectar y guardar los datos en la base de datos
        try:
            SERVER = 'localhost' 
            USER = 'informatica2'   
            PASSWD = 'bio123' 
            DB = 'info_2' 

            cnx = mysql.connector.connect(user=USER , password=PASSWD , host=SERVER , database=DB )

            cursor = cnx.cursor()
          
            sql_insert = """INSERT  INTO  usuarios (nombre, edad, genero, identificacion)
                    VALUES (%s,%s,%s,%s,%s,%s)"""
                    

            cursor.execute(sql_insert,(nombre, edad, genero, identificacion))
            cnx.commit()

            QMessageBox.information(self, "Éxito", "Datos guardados correctamente.")
        
        except mysql.connector.Error as error:
            QMessageBox.critical(self, "Error", f"No se pudo guardar la información: {error}")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Ocurrió un error inesperado: {str(e)}")
        
        finally:
            if cnx.is_connected():
                cursor.close()
                cnx.close()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    ventana = Ventana()
    ventana.show()
    sys.exit(app.exec_())
