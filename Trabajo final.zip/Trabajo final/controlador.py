from modelo import Modelo
from vista import Ventana, Ventana2
import sys
from PyQt5.QtWidgets import QApplication
from modelo import Juego
from modelo import JuegoEscritura

class Controlador:
    def __init__(self):
        self.modelo = Modelo()  # Instancia del modelo que contiene la lógica del juego y los datos
        self.app = QApplication(sys.argv)  # Inicialización de la aplicación PyQt
        self.ventana1 = Ventana(self)  # Ventana inicial
        self.ventana2 = None  # Se inicializa en None y se crea al abrir la segunda ventana
        self.juego_escritura = None
        self.juego = None
        

    def guardar_datos(self):
        """Recupera datos ingresados en los campos de texto de la ventana 1 y los guarda en el modelo."""
        nombre = self.ventana1.lineEdit.text()
        edad = self.ventana1.lineEdit_2.text()
        genero = self.ventana1.lineEdit_3.text()
        identificacion = self.ventana1.lineEdit_4.text()

        # Verificar que todos los campos estén llenos
        if not (nombre and edad and genero and identificacion):
            self.ventana1.mostrar_advertencia("Por favor, complete todos los campos.")
            return

        # Intentar guardar los datos en el modelo
        if self.modelo.guardar_datos(nombre, edad, genero, identificacion):
            self.ventana1.mostrar_mensaje("Éxito", "Datos guardados correctamente.")
            self.abrir_ventana2()
        else:
            self.ventana1.mostrar_advertencia("No se pudo guardar la información.")

    def abrir_ventana2(self):
        """Abre la segunda ventana del sistema."""
        self.ventana2 = Ventana2(self)
        self.ventana2.show()
        self.ventana1.close()
    
    
    def iniciar_juego(self):
        if self.juego is None:
            self.juego = Juego()  
        self.juego.jugar()  # Inicia el juego
        
        tiempos_reaccion = self.juego.tiempos_reaccion
        
        identificacion = self.ventana1.lineEdit_4.text()
        promedio = self.juego.promedio_tiempo_reaccion
        desviacion = self.juego.desviacion_tiempo_reaccion
        if promedio != 0 and desviacion != 0:
           print(f"Datos a guardar - Identificación: {identificacion}, Promedio: {promedio}, Desviación: {desviacion}")
           self.modelo.guardar_resultados_mouse(identificacion, promedio, desviacion)
        else:
           print("Error: No se calcularon correctamente los tiempos de reacción.")

        
        
    def jugar_teclado(self):
        if self.juego_escritura is None:  # Verificamos si la instancia no está creada
            self.juego_escritura = JuegoEscritura()  # Creamos la instancia si es necesario
        self.juego_escritura.juego_escritura()
        identificacion = self.ventana1.lineEdit_4.text()
        
        promedio = self.juego_escritura.promedio_tiempo_reaccion  # Obtener el promedio de tiempo de reacción
        desviacion = self.juego_escritura.desviacion_tiempo_reaccion  # Obtener la variación estándar de tiempo de reacción
        
        if promedio != 0 and desviacion != 0:
           print(f"Datos a guardar - Identificación: {identificacion}, Promedio: {promedio}, Desviación: {desviacion}")
           self.modelo.guardar_resultados_teclado(identificacion, promedio, desviacion)
        else:
           print("Error: No se calcularon correctamente los tiempos de reacción.")


    def salir(self):
        """Regresa a la ventana inicial desde la ventana 2."""
        self.ventana1 = Ventana(self)
        self.ventana1.show()
        self.ventana2.close()
        
    def ejecutar(self):
        """Ejecuta la aplicación."""
        self.ventana1.show()
        sys.exit(self.app.exec_())


if __name__ == "__main__":
    controlador = Controlador()
    controlador.ejecutar()

