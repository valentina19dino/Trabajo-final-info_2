import mysql.connector
import pygame
import random
import time 
from datetime import datetime
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd


class Modelo:
    def __init__(self):
        self.SERVER = 'localhost'
        self.USER = 'informatica2'
        self.PASSWD = 'bio123'
        self.DB = 'info_2'

    def guardar_datos(self, nombre, edad, genero, identificacion):
        try:
            cnx = mysql.connector.connect(user=self.USER, password=self.PASSWD, host=self.SERVER, database=self.DB)
            cursor = cnx.cursor()
            sql_insert = """INSERT INTO usuarios (nombre, edad, genero, identificacion) VALUES (%s, %s, %s, %s)"""
            cursor.execute(sql_insert, (nombre, edad, genero, identificacion))
            cnx.commit()
            return True
        except mysql.connector.Error as error:
            print(f"Error: {error}")
            return False
        finally:
             if cnx.is_connected():
                cursor.close()
                cnx.close()

    def guardar_resultados_teclado(self, identificacion, promedio_tiempos, variacion_estandar):
        try:
            cnx = mysql.connector.connect(user=self.USER, password=self.PASSWD, host=self.SERVER, database=self.DB)
            cursor = cnx.cursor()
            sql_insert = """INSERT INTO resultados_teclado (identificacion, promedio_tiempos, variacion_estandar) VALUES (%s, %s, %s)"""
            cursor.execute(sql_insert, (identificacion, promedio_tiempos, variacion_estandar))
            cnx.commit()
            print("Resultados guardados exitosamente en la tabla resultados_teclado.")
        except mysql.connector.Error as error:
            print(f"Error al guardar resultados: {error}")
        finally:
            if cnx.is_connected():
                cursor.close()
                cnx.close()

    def guardar_resultados_mouse(self, identificacion, promedio, desviacion):
        try:
            cnx = mysql.connector.connect(user=self.USER, password = self.PASSWD, host = self.SERVER, database = self.DB)
            cursor = cnx.cursor()
            sql_insert = """INSERT INTO resultados_mouse(identificacion, promedio, desviacion) VALUES (%s, %s, %s)"""
            cursor.execute(sql_insert, (identificacion, promedio, desviacion))
            cnx.commit()
            print("Resultados guardados exitosamente en la tabla resultados_mouse.")
        except mysql.connector.Error as error:
            print(f'Error al guardar resultados : {error}')
        finally:
            if cnx.is_connected():
                cursor.close()
                cnx.close()
                       
    # Juego de escritura

class JuegoEscritura():
    
    def __init__(self):
        self.PALABRAS = ["cielo", "vivir", "adaptación", "ayudar", "coordinación", "escritura", "rehabilitación", "tecnología", "innovación", "biología", "físico", "química", "matemáticas", "computadora", "aprendizaje", "desarrollo", "científico", "experimentación", "futuro", "progreso", "creación", "investigación", "salud", "comunicación", "educación", "ecología", "crecimiento", "paz", "amor", "naturaleza", "familia", "sociedad", "ambiente", "energía", "eficiencia", "creatividad", "cultura", "arte", "música", "bailar", "pintura", "diseño", "fotografía", "espejo", "sueño", "vida", "esperanza", "camino", "libertad", "felicidad", "futuro", "sabiduría", "valores", "responsabilidad", "ética", "solidaridad", "emprendimiento", "confianza", "amistad", "desafío", "teoría", "experiencia", "justicia", "equidad", "honestidad", "compromiso", "valor", "dignidad", "sostenibilidad", "poder", "teoría", "práctica", "justicia", "equilibrio", "paz", "proyecto", "acción", "trabajo", "dedicación", "logro", "superación", "resiliencia", "fortaleza", "energía", "transformación", "habilidad", "metas", "progreso", "revolución", "socorro", "belleza", "decisión", "desempeño", "productividad", "crecer", "avanzar", "fuerza", "unidad", "valoración", "reflexión", "ambición", "trabajo", "familia", "estudio"]
        self.score = 0
        self.tiempos_reaccion = []
        self.width = 800
        self.height = 600
        self.promedio_tiempo_reaccion = 0
        self.desviacion_tiempo_reaccion = 0
    
    def juego_escritura(self):
             
        pygame.init()
        WIDTH, HEIGHT = 800, 600
        screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption("Juego de Escritura")
        FONT = pygame.font.Font(None, 74)
        SMALL_FONT = pygame.font.Font(None, 50)
        WHITE = (255, 255, 255)
        BLACK = (0, 0, 0)
        RED = (255, 0, 0)
        GREEN = (0, 255, 0)
    
        
        start_time = pygame.time.get_ticks() / 1000
        tiempos_reaccion = []
        palabra_actual = random.choice(self.PALABRAS)
        entrada_usuario = ""
        score = 0
        feedback = ""
        feedback_color = BLACK
        terminado = False
    
        while not terminado:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    terminado = True
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_BACKSPACE:
                        entrada_usuario = entrada_usuario[:-1]
                    elif event.key == pygame.K_RETURN:
                        if entrada_usuario.strip().lower() == palabra_actual.lower():
                            tiempo_reaccion = pygame.time.get_ticks() / 1000 - start_time
                            tiempos_reaccion.append(tiempo_reaccion)
                            score += 1
                            feedback = f"¡Correcto! Tiempo: {tiempo_reaccion:.2f}s"
                            feedback_color = GREEN
                            entrada_usuario = ""
                            palabra_actual = random.choice(self.PALABRAS)
                            start_time = pygame.time.get_ticks() / 1000
                        else:
                            feedback = "Incorrecto. Intenta de nuevo."
                            feedback_color = RED
                            entrada_usuario = ""
                    else:
                        entrada_usuario += event.unicode
    
            screen.fill(WHITE)
            texto_palabra = FONT.render(palabra_actual, True, BLACK)
            screen.blit(texto_palabra, (WIDTH // 2 - texto_palabra.get_width() // 2, HEIGHT // 3))
            texto_entrada = FONT.render(entrada_usuario, True, BLACK)
            screen.blit(texto_entrada, (WIDTH // 2 - texto_entrada.get_width() // 2, HEIGHT // 2))
            texto_feedback = SMALL_FONT.render(feedback, True, feedback_color)
            screen.blit(texto_feedback, (WIDTH // 2 - texto_feedback.get_width() // 2, HEIGHT // 1.5))
            texto_score = SMALL_FONT.render(f"Puntuación: {score}", True, BLACK)
            screen.blit(texto_score, (20, 20))
            pygame.display.flip()
    
        self.mostrar_graficas(tiempos_reaccion)
    
    def mostrar_graficas(self, tiempos_reaccion):
        if not tiempos_reaccion:
            print("No se capturaron tiempos de reacción.")
            return
        
        # Uso de numpy para estadísticas
        tiempos_np = np.array(tiempos_reaccion)
        self.promedio_tiempo_reaccion = np.mean(tiempos_np)
        self.desviacion_tiempo_reaccion = np.std(tiempos_np)
        
        print(f"Promedio de tiempos: {self.promedio_tiempo_reaccion:.2f}s")
        print(f"Desviación estándar: {self.desviacion_tiempo_reaccion:.2f}s")
        
        # Crear un DataFrame con pandas
        datos = pd.DataFrame({
            "Intentos": range(1, len(tiempos_reaccion) + 1),
            "Tiempo de Reacción": tiempos_reaccion
        })
        print("Datos capturados:\n", datos)
        
        # Configurar y mostrar la gráfica
        sns.set(style="whitegrid")
        plt.figure(figsize=(10, 6))
        plt.plot(datos["Intentos"], datos["Tiempo de Reacción"], marker="o", color="b", label="Tiempo de Reacción")
        plt.title("Evolución del Tiempo de Reacción")
        plt.xlabel("Intentos")
        plt.ylabel("Tiempo de Reacción (segundos)")
        plt.legend()
        plt.show()
        
        
# Definimos colores
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

# Definimos la clase Meteor
class Meteor(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load("meteor.png").convert()  
        self.image.set_colorkey(BLACK)  
        self.rect = self.image.get_rect()

# Definimos la clase Player (jugador)
class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load("player.png").convert()  
        self.image.set_colorkey(BLACK)
        self.rect = self.image.get_rect()

class Juego:
    def __init__(self):
        # Inicialización de pygame
        pygame.init()

        # Configuración de la ventana del juego
        self.screen = pygame.display.set_mode([900, 600])
        pygame.display.set_caption("Recoge Meteoritos")

        # Configuración del reloj
        self.clock = pygame.time.Clock()

        # Listas de meteoros y jugador
        self.meteor_list = pygame.sprite.Group()
        self.all_sprite_list = pygame.sprite.Group()

        # Crear meteoritos
        for i in range(50):
            meteor = Meteor()
            meteor.rect.x = random.randrange(900)
            meteor.rect.y = random.randrange(600)
            self.meteor_list.add(meteor)
            self.all_sprite_list.add(meteor)

        # Crear el jugador
        self.player = Player()
        self.all_sprite_list.add(self.player)

        # Inicializar el puntaje y tiempos
        self.score = 0
        self.start_time = time.time()
        self.done = False
        self.tiempos_reaccion = []
        
        # Inicializar variables de promedio y desviacion 
        self.promedio_tiempo_reaccion = 0
        self.desviacion_tiempo_reaccion = 0

    def jugar(self):
        while not self.done:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.done = True

            # Movimiento del jugador con el mouse
            mouse_pos = pygame.mouse.get_pos()
            self.player.rect.x = mouse_pos[0]
            self.player.rect.y = mouse_pos[1]

            # Colisión con los meteoros
            meteor_hit_list = pygame.sprite.spritecollide(self.player, self.meteor_list, True)

            for meteor in meteor_hit_list:
                self.score += 1
                print(f"Meteorito recogido: {self.score}")

                # Tiempo de reacción
                reaction_time = time.time() - self.start_time
                self.tiempos_reaccion.append(reaction_time)
                self.start_time = time.time()

            # Si se han recogido todos los meteoros, finalizar el juego
            if self.score == 50:
                print(f"Todos los meteoros recogidos.")
                self.calcular_estadisticas()  # Llamar a mostrar estadísticas y graficar
                self.done = True  # Fin del juego

            # Dibujar sprites
            self.screen.fill(WHITE)
            self.all_sprite_list.draw(self.screen)
            pygame.display.flip()
            self.clock.tick(60)

        # Este es el momento correcto para cerrar pygame después de haber mostrado las estadísticas y gráfico
        pygame.quit()

    def calcular_estadisticas(self):
        """Mostrar estadísticas con los tiempos de reacción."""
        if not self.tiempos_reaccion:
            print("No hay tiempos de reacción para mostrar.")
            return

        # Crear un DataFrame para estadísticas
        df_tiempos = pd.DataFrame({"Tiempo de Reacción": self.tiempos_reaccion})
        self.promedio_tiempo_reaccion = df_tiempos["Tiempo de Reacción"].mean()
        self.desviacion_tiempo_reaccion = df_tiempos["Tiempo de Reacción"].std()

        print(f"\nPromedio: {self.promedio_tiempo_reaccion:.2f}s, Desviación estándar: {self.desviacion_tiempo_reaccion:.2f}s")
        
        self.graficar_tiempos(df_tiempos)

    def graficar_tiempos(self, df_tiempos):
        """Generar y mostrar el gráfico de tiempos de reacción."""
        plt.figure(figsize=(10, 6))
        plt.plot(df_tiempos.index + 1, df_tiempos["Tiempo de Reacción"], marker='o', color='b', label="Tiempo de Reacción")
        plt.axhline(df_tiempos["Tiempo de Reacción"].mean(), color='r', linestyle='--', label="Promedio")
        plt.title("Tiempos de Reacción por Intento")
        plt.xlabel("Intento")
        plt.ylabel("Tiempo de Reacción (s)")
        plt.legend()
        plt.grid(True)
        plt.show()  # Muestra la gráfica




        
        