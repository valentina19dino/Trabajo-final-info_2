from PyQt5.QtWidgets import QMainWindow, QMessageBox
from PyQt5.uic import loadUi

class Ventana(QMainWindow):
    def __init__(self, controlador):
        super(Ventana, self).__init__()
        loadUi("ventana_1.ui", self)
        self.controlador = controlador
        self.boton_ingresar.clicked.connect(self.controlador.guardar_datos)

    def mostrar_mensaje(self, titulo, mensaje):
        QMessageBox.information(self, titulo, mensaje)

    def mostrar_advertencia(self, mensaje):
        QMessageBox.warning(self, "Advertencia", mensaje)

class Ventana2(QMainWindow):
    def __init__(self, controlador):
        super(Ventana2, self).__init__()
        loadUi("ventana_2.ui", self)
        self.controlador = controlador
        self.boton_teclado.clicked.connect(self.controlador.jugar_teclado)
        self.boton_mouse.clicked.connect(self.controlador.iniciar_juego)
        self.boton_salir.clicked.connect(self.controlador.salir)
