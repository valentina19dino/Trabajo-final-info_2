-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 03-12-2024 a las 08:13:44
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `info_2`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `resultados_mouse`
--

CREATE TABLE `resultados_mouse` (
  `identificacion` int(25) NOT NULL,
  `promedio` float NOT NULL,
  `desviacion` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `resultados_mouse`
--

INSERT INTO `resultados_mouse` (`identificacion`, `promedio`, `desviacion`) VALUES
(963, 0, 0),
(852, 0.128373, 0.136623),
(741, 0.109655, 0.127362),
(456, 0.103139, 0.115797),
(789, 0.089776, 0.105027),
(357, 0.164697, 0.145617),
(222, 0.0985332, 0.11051),
(721, 0.105389, 0.133969),
(555, 0.135514, 0.362596),
(432, 0.136987, 0.319518),
(245, 0.0928784, 0.101372);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `resultados_teclado`
--

CREATE TABLE `resultados_teclado` (
  `identificacion` int(20) NOT NULL,
  `promedio_tiempos` float NOT NULL,
  `variacion_estandar` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `resultados_teclado`
--

INSERT INTO `resultados_teclado` (`identificacion`, `promedio_tiempos`, `variacion_estandar`) VALUES
(159, 3.73076, 1.41118),
(357, 4.49889, 2.00818),
(456, 5.00944, 1.86191),
(417, 4.702, 1.23017),
(5641, 2.9982, 0.88573),
(222, 5.3932, 2.38197),
(555, 3.14091, 0.700058),
(432, 5.174, 2.62064),
(245, 3.87408, 1.53307);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `nombre` text NOT NULL,
  `edad` int(11) NOT NULL,
  `genero` text NOT NULL,
  `identificacion` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`nombre`, `edad`, `genero`, `identificacion`) VALUES
('Juan', 25, 'Masculino', 123),
('Valentina', 18, 'Femenino', 123),
('Valeria', 29, 'Femenino', 12),
('Fernando', 17, 'Masculino', 213),
('Juana', 13, 'Femenino', 789),
('Pedro', 45, 'Masculino', 456),
('Samuel', 78, 'Masculino', 963),
('Sofia', 55, 'Femenino', 852),
('Juan', 66, 'Masculino', 741),
('Luciano', 17, 'Masculino', 456),
('Daniel', 63, 'Masculino', 789),
('Luna', 26, 'Femenino', 321),
('Lorenzo', 54, 'Masculino', 654),
('Franco', 85, 'Masculino', 159),
('Sol', 74, 'Femenino', 357),
('Pablo', 19, 'Masculino', 654),
('Juana', 55, 'Femenino', 951),
('Andres', 85, 'Masculino', 3218),
('Miguel', 99, 'Masculino', 456),
('Luisa', 27, 'Femenino', 417),
('Isabel', 55, 'Femenino', 753),
('Fanny', 64, 'Femenino', 568),
('Ismael', 12, 'Masculino', 987),
('Luna', 45, 'Femenino', 639),
('Jose', 63, 'Masculino', 682),
('Manuela', 85, 'Femenino', 50001),
('Jose luis', 59, 'Masculino', 584),
('Juan Felipe', 20, 'Masculino', 612),
('Sebastian', 96, 'Masculino', 888),
('Andrea', 19, 'Femenino', 5641),
('Daniela', 45, 'Femenino', 222),
('Daissy', 28, 'Femenino', 6548),
('German', 75, 'Masculino', 444),
('Danilo', 55, 'Masculino', 6593),
('Renata', 68, 'Femenino', 2156),
('Simón', 19, 'Masculino', 587),
('Sonia', 88, 'Femenino', 862),
('Tiana', 45, 'Femenino', 734),
('Yuliana', 24, 'Femenino', 245),
('Ricardo', 96, 'Mascculino', 964),
('Pola', 45, 'Femenino', 549),
('Esteban ', 26, 'Masculino', 384),
('Esteban ', 26, 'Masculino', 384),
('Esteban ', 26, 'Masculino', 711),
('Rodrigo', 61, 'Masculino', 721),
('Valentino', 27, 'Masculino', 555),
('Sandra', 51, 'Femenino', 432),
('Julian', 28, 'Masculino', 245);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
